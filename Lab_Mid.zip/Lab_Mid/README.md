# FA23-BSE-040-Section-A-MuhammadAbdullahNadeem
LAB 1 Task
<img width="1028" height="682" alt="Task1" src="https://github.com/user-attachments/assets/96257a2a-eece-481c-bf43-845335d163f7" />

Lab2 Task

<img width="1365" height="715" alt="Lab2T2" src="https://github.com/user-attachments/assets/df254bcd-0121-4a6e-865d-c0e581b5c5c4" />

Lab 4 TASK








![task3](https://github.com/user-attachments/assets/431bd5f6-d709-4c32-a280-a7bd4b9a8312)
